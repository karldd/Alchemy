/*
 * This file is part of the Alchemy project - http://al.chemy.org
 * 
 * Copyright (c) 2007-2010 Karl D.D. Willis
 * 
 * Alchemy is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Alchemy is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Alchemy.  If not, see <http://www.gnu.org/licenses/>.
 */

/** This is the package where Affect modules live */
package org.alchemy.affect;

/** Import the entire Alchemy 'core' */
import org.alchemy.core.*;

/** Import some Java objects that are useful for handling mouse events */
import java.awt.event.MouseEvent;

/**
 *
 * AffectModule.java
 * 'AffectModule' is the name of the module
 * and it must match the filename.
 * 
 * AlcModule is the Alchemy template for a module
 * that does some basic functionality for us
 * such as loading up and telling us when the mouse is moved etc...
 * 
 * We extend AlcModule to add additionaly functionality.
 * 
 */
public class AffectModule extends AlcModule {

    // Note there is now constructor, use setup() instead

    // Override means to override the default functions given to us by AlcModule
    @Override
    protected void setup() {
        // This function is called when the module is first selected in the menu
        // It will only be called once, so is useful for doing stuff like
        // loading interface elements into the menu bar etc...
    }

    @Override
    protected void cleared() {
        // This function is called when the canvas is cleared
        // You might sometimes need to use it
        // if you are say counting the number of shapes
        // and you want to know when to set it back to zero
    }

    @Override
    protected void reselect() {
        // This function is called when the module is reselected in the menu
        // i.e. the module is turned off then on again
    }

    @Override
    protected void affect() {
        // This function is called only on affect modules
        // It is called everytime the canvas is redrawn
        // The idea is that affect modules can affect a shape
        // that the create module has created

        // Create a random number between 1 and 25
        float randomNumber = math.random(1, 25);

        // Check that there is a shape available
        if (canvas.hasCreateShapes()) {
            // Set the line width of the shape to the random number
            canvas.getCurrentCreateShape().setLineWidth(randomNumber);
        }

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        // This function is called when the mouse/pen moves
        // It is called A LOT
    }

    @Override
    public void mousePressed(MouseEvent e) {
         // This function is called when the mouse/pen is pressed
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        // This function is called when the mouse/pen is dragged
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // This function is called when the mouse/pen is released
    }
}
