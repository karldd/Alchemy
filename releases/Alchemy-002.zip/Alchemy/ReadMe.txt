Alchemy
ALPHA 002


ABOUT --------------------------------

Alchemy is an open drawing project aimed at exploring how we can sketch, 
draw, and create on computers in new ways. Alchemy isn't software for 
creating finished artwork, but rather a sketching environment that focuses 
on the absolute initial stage of the creation process. Experimental in nature, 
Alchemy lets you brainstorm visually to explore an expanded range of ideas 
and possibilities in a serendipitous way.



INSTALLATION -------------------------

Simply copy the Alchemy folder to wherever you keep your applications.

The 'modules' folder must remain together with the application. 
Individual modules can be removed if not required, however be sure to
not mix older modules with newer versions or vice versa.



CREDITS/LICENSE ----------------------
Alchemy was initiated by Karl D.D. Willis & Jacob Hina. 
The source code is 
released under the GNU General Public License and Copyright � 2007-2008 
Karl D.D. Willis. Please see the 'COPYING' file for the full license.



WEB ----------------------------------

Alchemy website: http://al.chemy.org/

Download Alchemy: http://al.chemy.org/download/

Alchemy Forum: http://al.chemy.org/forum/





Version History
--------------------------------------
ALPHA 002

 FEATURES
  + The toolbar is now detachable into a seperate palette window
  + Trace Shapes / Speed Shapes / X Shapes modules added
  + Copy function to copy the canvas to the clipboard as a bitmap
  + Alchemy Help added
  + Japanese Localisation
  + Canvas smoothing option added
  + Background colour is now changeable

 CHANGES
  + PDF saving functionality improved. PDF files are now viewable throughout
  + Interface improvements, icon changes
  + Random module now has a distortion slider
  + Type Shapes module can now create shapes using the mouse and keyboard
  + More robust microphone detection and more accurate sound levels

 BUG FIXES
  + Toolbar hiding functionality improved
  + Toolbar repainting when drawing 'blind' fixed
  + Shortcut key mappings fixed
  + Fullscreen mode on a mac is now stable

--------------------------------------
ALPHA 001

 Initial Release


