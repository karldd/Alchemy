Alchemy (001 Alpha)





ABOUT --------------------------------

Alchemy is an open drawing project aimed at exploring how we can sketch, 
draw, and create on computers in new ways. Alchemy isn't software for 
creating finished artwork, but rather a sketching environment that focuses 
on the absolute initial stage of the creation process. Experimental in nature, 
Alchemy lets you brainstorm visually to explore an expanded range of ideas 
and possibilities in a serendipitous way.



INSTALLATION -------------------------

Simply copy the Alchemy folder to wherever you keep your applications.

The 'modules' folder must remain together with the application. 
Individual modules can be removed if not required.



CREDITS/LICENSE ----------------------
Alchemy was initiated by Karl D.D. Willis & Jacob Hina. 
The source code is 
released under the GNU General Public License and Copyright � 2007-2008 
Karl D.D. Willis. Please see the 'COPYING' file for the full license.



WEB ----------------------------------

Alchemy website: http://al.chemy.org/

Download Alchemy: http://al.chemy.org/download/

Alchemy Forum: http://al.chemy.org/forum/
